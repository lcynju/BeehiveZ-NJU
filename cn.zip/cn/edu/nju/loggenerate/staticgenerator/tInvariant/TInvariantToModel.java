package cn.edu.nju.loggenerate.staticgenerator.tInvariant;

import java.util.List;

import cn.edu.nju.loggenerate.staticgenerator.model.ProcessModel;

public class TInvariantToModel {

	private ProcessModel processModel;
	
	public TInvariantToModel( ProcessModel processModel) {
		this.processModel = processModel;
	}
	
	public List<ProcessModel> convertToModel(List<List<String>> tInvariants){
		
		return null;
	}
}
