package cn.edu.thss.iise.beehivez.server.index.mcmillanindex.queryparser;

public class TaskSetTypeTag {
	public final static int
	SPECIFIC = 1,
	CONSTRUCTION = 2,
	APPICATION = 3,
	VARNAME = 4;

}
