package cn.edu.thss.iise.beehivez.server.index.bplustree;

public class BplusTreeBadKeyValue extends Exception {
	public BplusTreeBadKeyValue(String message)// : base(message)
	{
		super(message);
	}
}