package cn.edu.thss.iise.beehivez.server.index.mcmillanindex.queryparser;

public class PredictTypeTag {
	public static final int
	BINLOGOP = 1,
	UNLOGOP = 2,
	EXIST = 3,
	SETCOMOP = 4,
	TASKCOMPOP = 5;
}
