package cn.edu.thss.iise.beehivez.server.index.mcmillanindex.queryparser;

public class TaskIDTable {
	public String taskname;
	public int id;
	
	public TaskIDTable(String name, int tid){
		taskname = name;
		id = tid;
	}
	
}
