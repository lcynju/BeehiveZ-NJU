package cn.edu.thss.iise.beehivez.server.index.mcmillanindex.queryparser;

public class OperatorTag {
	public final static int
	AND = 256,
	OR  = 257,
	NOT = 258,
	EXIST = 261,
	SUCCOF = 262,
	PREDOF = 263,
	ISUCCOF = 264,
	IPREDOF = 265,
	CONCUROF = 266,
	NONCONCUROF = 267,
	IDENTICAL = 268,
	SUBSETOF = 269,
	OVERLAP = 270,
	UNION = 271,
	DIFFERENCE = 272,
	INTERSECTION = 273;
}
